
Readme file for simulated LFP signals with embedded oscillations
================================================================

This is a benchmark dataset for the evaluation of oscillations embedded in realistic 1/f distributed LFP signals, as used in the paper "A method for closed-loop presentation of sensory stimuli conditional on the internal brain-state of awake animals" by U. Rutishauser, A. Kotowicz and G. Laurent; Journal of Neuroscience Methods (http://dx.doi.org/10.1016/j.jneumeth.2013.02.020).

Each file contains a simulated LFP trace of 130s length,with 30 simulated oscillatory events embedded.
The amplitude, length and oscillatory frequency of the events is modified in each instance to systematically test different frequencies and difficulty levels.

All data is at 250Hz sampling rate, in arbitrary units.

We used these files both for performance benchmarking of oscillation detection algorithms. The files can be used both for replay via a D/A converter as well as simulations.


Variables in each file
======================

Xorig                   simulated LFP trace, before the oscillations are embedded. It contains very low frequencies <0.1Hz, highpass-filter before using it.
X                       the simulated LFP trace, 0.5 Hz high-pass filtered and 30 oscillations inserted.
XfreqInserted           location of inserted oscilaltions 
FsDown                  the sampling rate (250Hz)
thisSNR                 the SNR (measured) of the inserted oscillations
fToSim                  frequency of each inserted episode
locToInsert             start position of each episode
modeDriftFreqs          does the frequency drift or is it stable within an episode
totLength               total length of the trace (130s)
modeRandomizeStartPhase yes/no. If yes, the start phase of each episode is randomized.


Versions
========

We provide version for 8Hz, 20Hz, and 40Hz. Frequencies vary randomly by +- 10% for each episode around the target frequency. The frequency of the oscillation within the episode is constant. There are 4 different runs for each frequency, totallying 120 episodes for each frequency. Each is provided for 5 different levels of SNR.

File name:
simLFP_j_i_f.mat

j is the noise level (1-5, from easy to difficult; see variable thisSNR in each file)
i run number
f is the oscillatory frequency


License and citation
====================

This is a public dataset which anyone is free to use. The latest version can be found at http://stimomatic.brain.mpg.de/.
Please cite "A method for closed-loop presentation of sensory stimuli conditional on the internal brain-state of awake animals" by U. Rutishauser, A. Kotowicz and G. Laurent; Journal of Neuroscience Methods (http://dx.doi.org/10.1016/j.jneumeth.2013.02.020) if you do so.


